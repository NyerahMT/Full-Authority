# F-16 NATO visual asset attribution

- **Model:** F-16 Fighting Falcon | NATO | GameReady
- **Creator:** Pan_Ar4ik
- **Source:** Sketchfab
- **License:** Creative Commons Attribution (CC BY)

This repository contains an optimized runtime conversion of the credited model. The original FBX was supplied by the project owner and is not required at runtime. Geometry was reoriented/scaled for Full Authority, stores were omitted, and the horizontal stabilators were split from the static airframe so JSBSim can continue to drive them.
